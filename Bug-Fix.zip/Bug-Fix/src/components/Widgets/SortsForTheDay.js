/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import NumberClass from 'Util/NumberClass';

class SortsForTheDay extends Component {

	state = {
			data: [],
			label: null,
			graphData: null
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		api.get(baseURL+'inductsfortheday/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
		 .then(res => {
			    console.log(res.data);
			    let label = res.data.inductsForTheDayList.map(list => list.currentDt);
			    let graphData = res.data.inductsForTheDayList.map(list => list.curr_value);
			    
			    console.log(graphData);
		        this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData
					        });
		   }).catch(function (error) {
				console.log(error);
		  });
	}

	render() {
		const { recentOrders } = this.state;
		const percentage  = this.state.data.percentValue

		return (
				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Sorts for the day"}
				fullBlock
				>
					<div className="clearfix">
	                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
	                    <div className="d-flex">
	                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
	                        	<CircularProgressbar percentage={this.state.data.percentValue}
	                        						 text={`${this.state.data.percentValue}%`}
	                        						 backgroundPadding={10}
	                        						 styles={{ path: { stroke: 'rgba(135,0,56)', strokeLinecap: 'butt' },
	                        							 	   text: { fill: '#121212', fontSize: '25px', textAnchor: "middle", dominantBaseline: "middle"},
	                        							 	   trail: { stroke: '#d7d7d7' },
	                        							 	   background: { fill: '#fffff' }
	                        						 }}
	                        	/>
	                        </div>
	                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
	                                <span className="counter-point">
										<strong>&nbsp; <NumberClass  number={this.state.data.currentValue} />  / &nbsp;
											<span><NumberClass  number={this.state.data.goalValue} /></span></strong>
	                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
	                                </span>
	                            </div>
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
								<div className="lastdays-text">Last 5 days</div>
	                                <TinyAreaChart
	                                    label="Visitors"
	                                    chartdata={this.state.graphData}
	                                    labels={this.state.label}
	                                    backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
	                                    borderColor={'#870038'}
	                                    lineTension="0"
	                                    height={130}
	                                    gradient
	                                />
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </RctCollapsibleCard>
		);
	}
}

export default SortsForTheDay;
